The Project was completed by creating a web page that uses java script to retrieve the json file and display the relevant information.
To view simply open CodingExercise.html in your favorite browser.
No setup required.
